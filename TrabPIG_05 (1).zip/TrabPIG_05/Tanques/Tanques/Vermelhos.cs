﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Tanques
{
    class Vermelhos : Azuis
    {
        public Azuis alvoB;
        public Vermelhos()
            : base()
        {
            alvoB = new Azuis();
            position = new Vector2(0, 0);
            lapis = new Pen(Color.Red, 1);
            pincel = new SolidBrush(Color.Red);
            pincel2 = new SolidBrush(Color.DarkRed);
            pincel3 = new SolidBrush(Color.IndianRed );
        }
        public void Seekblues(Azuis tb)
        {
            if (Vivo == true)
            {
                float distancia = (int)(Math.Sqrt((Math.Pow((this.getPosition().X - tb.getPosition().X), 2) + Math.Pow((this.getPosition().Y - tb.getPosition().Y), 2))));
                if (distancia < alcance / 2 && tb.Vivo == true)
                {
                    alvoB = tb;
                    seek = true;
                    Disparo = true;

                }
                else {

                    alvoB = new Azuis();
                    alvoB.setPosition(new Vector2(0, 0));
                    alvoB.setVelocity(new Vector2(0));
                    Disparo = false;
                }
            }
            else { seek = false; Disparo = false;  }

        }// metodo para procurar tanks azuis
        public Boolean LevouTiroRed(Disparar t)
        {
           
            if (t.TiroBlue == true && Vivo == true)
            {
                float distancia = (int)(Math.Sqrt((Math.Pow((this.getPosition().X - t.Pos.X), 2) + Math.Pow((this.getPosition().Y - t.Pos.Y), 2))));
                if (distancia < 50f) { mass--; return true; }
                if (mass <= 1) {
                    vivo = false;
                    this.setPosition(new Vector2(0));
                    disparo = false;
                }

            }

            return false;
        }// metodo de registo de tiro / update de vida
        public override void update()
        {
            if (seek == true && mass > 1)
                navigate.seek(alvoB.getPosition());

            if (mass <= 1)
                navigate.flee(alvoB.getPosition());

            else
                navigate.wander();
            
            navigate.update();
            hitbox = new Rectangle(new Point((int)getPosition().X - hitSize.Width / 2, (int)getPosition().Y - hitSize.Height / 2), hitSize);

        }
    }
}
