﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Tanques
{
    class NavegaComp
    {
        const float MAX_FORCE = 1f;
        const float CIRCLE_DISTANCE = 2F;
        const float CIRCLE_RADIUS = 1F;
        const float ANGLE_CHANGE = 0.5F;

        public Vector2 navega;
        public Boid host;

        private float wanderAngle;
        private Random rnd;

        public NavegaComp(Boid h)
        {
            host = h;
            navega = new Vector2(0);
            wanderAngle = 0f;
            rnd = new Random((int)DateTime.Now.Ticks);
        }

        public void seek(Vector2 target)
        {
            navega += doSeek(target);
        }

        private Vector2 doSeek(Vector2 target)
        {
            Vector2
                forca,
                position = host.getPosition(),
                velocity = host.getVelocity();
            Vector2 desejo = Vector2.Normalize(target - position) * host.getMaxVelocity();
            forca = desejo - velocity;

            return forca;
        }

        public void wander()
        {
            navega += doWander();
        }

        private Vector2 setAngle(Vector2 vector, float angle)
        {
            float len = vector.Length();
            vector.X = (float)Math.Cos(angle) * len;
            vector.Y = (float)Math.Sin(angle) * len;
            return vector;
        }

        public Vector2 doWander()
        {
            Vector2 circleCenter,
                velo = host.getVelocity();

            circleCenter = new Vector2(velo.X, velo.Y);
            if (circleCenter.Length() == 0) circleCenter = new Vector2(CIRCLE_DISTANCE);
            else circleCenter = Vector2.Normalize(circleCenter) * CIRCLE_DISTANCE;
            Vector2 displacement = new Vector2(1, 0) * CIRCLE_RADIUS;
            wanderAngle += ((float)rnd.NextDouble() * ANGLE_CHANGE) - (ANGLE_CHANGE * 0.5f);
            displacement = setAngle(displacement, wanderAngle);
            Vector2 wanderForce = circleCenter + displacement;

            return wanderForce;
        }

        public void flee(Vector2 target)
        {
            navega += doFlee(target);
        }

        private Vector2 doFlee(Vector2 alvo)
        {
            Vector2
                pos = host.getPosition(),
                velo = host.getVelocity();
            Vector2 desired = Vector2.Normalize(pos - alvo) * host.getMaxVelocity();
            Vector2 force = desired - velo;
            return force;
        }

        public Vector2 truncate(Vector2 v, float max)
        {
            float i = max / v.Length();
            i = i < 1.0f ? i : 1.0f;
            return v * i;
        }

        public void update()
        {
            navega = truncate(navega, MAX_FORCE);
            navega = navega / host.getMass();
            Vector2 velo = truncate(host.getVelocity() + navega, host.getMaxVelocity());
            host.setVelocity(velo);
            Vector2 pos = host.getPosition() + velo;
            host.setPosition(pos);
            navega *= 0;
        }
    }
}
