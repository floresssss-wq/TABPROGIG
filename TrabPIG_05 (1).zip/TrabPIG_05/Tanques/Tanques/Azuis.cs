﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Tanques
{
    class Azuis : Boid
    {
        protected float max_velocity, rotation;
        protected int alcance, id;
        protected Vector2 position, velocity, busca, foge;
        protected int mass;
        protected NavegaComp navigate;
        protected Boolean seek, vivo, disparo, alcanceVisivel;

        protected Size area, areaC,hitSize;
        protected SizeF range;
        protected Point[] pontos, pontosCano, bala;
        protected Pen lapis, lapis2;
        protected SolidBrush pincel, pincel2, pincel3;
        protected Rectangle hitbox;
        public Vermelhos alvo;



        public Azuis()
        {
            max_velocity = 3f;
            mass = 4;// Hp do tank 
            seek = false;
            vivo = true;
            disparo = false;
            alcanceVisivel = false;
            rotation = 0;
            alcance = 400;

            position = new Vector2(0, 0);
            velocity = new Vector2(1);

            busca = new Vector2(0);
            foge = new Vector2(0);

            navigate = new NavegaComp(this);


            range = new Size(alcance, alcance);
            lapis = new Pen(Color.Blue, 1);
            lapis2 = new Pen(Color.Transparent, 1);
            pincel = new SolidBrush(Color.Blue);
            pincel2 = new SolidBrush(Color.DarkBlue);
            pincel3 = new SolidBrush(Color.Black);
            area = new Size(30, 15);
            areaC = new Size(40, 15);
            hitSize = new Size(20,15);
            hitbox = new Rectangle(new Point((int)-hitSize.Width / 2, (int)-hitSize.Height / 2), hitSize);
            definirPontos();

        }
        public Boolean Disparo
        {
            get { return disparo; }
            set { disparo = value; }
        }

        public Boolean AlcanceVisivel {
            get { return alcanceVisivel; }
            set { alcanceVisivel = value; }

        }
        public void definirPontos()
        {
            pontos = new Point[] {
               new Point(-area.Width/3, -area.Height/2),
               new Point(-area.Width/3, area.Height/2),
               new Point(area.Width/3, area.Height/2),
               new Point(area.Width/3, -area.Height/2)
            };

            bala = new Point[] {

               new Point(-areaC.Width/8, -area.Height/4),
               new Point(-areaC.Width/8, area.Height/4),
               new Point(areaC.Width/4, area.Height/4),
               new Point(areaC.Width/4, -area.Height/4)
            };

        }
        public Vector2 getVelocity()
        {
            return velocity;
        }

        public void setVelocity(Vector2 v)
        {
            velocity = v;
        }

        public float getMaxVelocity()
        {
            return max_velocity;
        }
        public void setMaxVelocity(float f)
        {
            max_velocity = f;
        }

        public Vector2 getPosition()
        {
            return position;
        }

        public void setPosition(Vector2 p)
        {
            position = p;
        }

        public void setAlcance(int n)
        {

            alcance = n;
        }
        public int getMass()
        {
            return mass;
        }

        public Rectangle getHitbox()
        {
             return hitbox; 
            
        }
        

        public void setMass(int i)
        {

            mass = i;
        }

        public float getRaio()
        {
            return area.Width / 2;
        }

        public Boolean Vivo
        {

            get { return vivo; }
            set { vivo = value; }
        }

        public int ID
        {

            get { return id; }
            set { id = value; }
        }
        public void Seekreds(Vermelhos tr)
        {
            if (Vivo == true)
            {
                float distancia = (int)(Math.Sqrt((Math.Pow((this.getPosition().X - tr.getPosition().X), 2) + Math.Pow((this.getPosition().Y - tr.getPosition().Y), 2))));
                if (distancia < alcance / 2 && tr.Vivo == true)
                {
                    alvo = tr;
                    seek = true;
                    Disparo = true;

                }
                else
                {

                    alvo = new Vermelhos();
                    alvo.setPosition(new Vector2(0, 0));
                    alvo.setVelocity(new Vector2(0));
                    Disparo = false;

                }



            }

            else { seek = false; Disparo = false; }



        }// serve para procurar tanks vermelhos

        public Boolean LevouTiroBlue(Disparar t)
        {

            if (t.TiroBlue == false && Vivo == true)
            {
                float distancia = (int)(Math.Sqrt((Math.Pow((this.getPosition().X - t.Pos.X), 2) + Math.Pow((this.getPosition().Y - t.Pos.Y), 2))));
                if (distancia < 50f) { mass--; return true; }
                if (mass <= 1)
                {
                    vivo = false;
                    this.setPosition(new Vector2(0));
                    Disparo = false;
                }

            }
            return false;

        } // metodo de registo de tiro / update de vida

        public virtual void update()
        {

            if (seek == true && mass > 1)
                navigate.seek(alvo.getPosition());

            if (mass <= 1)
                navigate.flee(alvo.getPosition());
            else
                navigate.wander();
            navigate.update();
            hitbox = new Rectangle(new Point((int)getPosition().X - hitSize.Width / 2, (int)getPosition().Y - hitSize.Height / 2), hitSize);

        }

        public virtual void draw(Graphics g)
        {
            RectangleF alcance = new RectangleF(new Point((int)-range.Width / 2, (int)-range.Height / 2), range);
            rotation = (float)Math.Atan2(velocity.Y, velocity.X) * 180 / (float)Math.PI;

            GraphicsPath path = new GraphicsPath();
            g.ResetTransform();

            g.RotateTransform(rotation);
            g.TranslateTransform(position.X, position.Y, MatrixOrder.Append);
            path.AddPolygon(pontos);              
            if (mass >= 4) g.FillPath(pincel, path);
            if (mass == 3) g.FillPath(pincel2, path);
            if (mass == 2) g.FillPath(pincel3, path);
            if(alcanceVisivel == true) g.DrawEllipse(lapis, alcance);
            g.ResetTransform(); 
            g.DrawRectangle(lapis2, hitbox);



        }
    }
}
