﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Tanques
{
    class Arena
    {
        private Size area;
        public int numeroDeTanques, timerBlue, timerRed, opcao;
        private Boolean start;
        private List<Azuis> tblues;
        private List<Vermelhos> treds;
        private List<Obstaculo> obstaculos;
        private Obstaculo paredes;
        private List<Disparar> tirosB, tirosR;
        private List<Region> listParedes;


        private static Arena instancia = null;

        private Arena(Size d)
        {
            opcao = 0;
            area = d;
            timerBlue = 0;
            timerRed = 0;
            listParedes = new List<Region>();
            numeroDeTanques = 5;
            tirosB = new List<Disparar>();
            tirosR = new List<Disparar>();
            tblues = new List<Azuis>();
            treds = new List<Vermelhos>();
            paredes = new Obstaculo();
            obstaculos = new List<Obstaculo>();

            criarTanque();





        }
        public void criarTanque()
        {
            for (int i = 1; i <= numeroDeTanques; i++)
            {
                Azuis b = new Azuis();
                Vector2 p = new Vector2((1000), (200 + i));
                b.setPosition(p);
                b.ID = i;
                tblues.Add(b);

                Vermelhos tr = new Vermelhos();
                tr.setPosition(new Vector2((100), (200 + i)));
                tr.ID = i;
                treds.Add(tr);
            }


        }

        public int getOpcao() { return opcao; }
        public void setAlcanceVisivel(Boolean b)
        {
            for (int i = 0; i < treds.Count; i++)
            {
                treds[i].AlcanceVisivel = b;
            }

            for (int i = 0; i < tblues.Count; i++)
            {
                tblues[i].AlcanceVisivel = b;
            }

        }
        public void defineArena(int n)
        {
            opcao = n;
            CriarParedes(opcao);
            listParedes = new List<Region>();
            foreach (Obstaculo o in obstaculos)
                listParedes.Add(new Region(new Rectangle(new Point((int)o.getPosition().X, (int)o.getPosition().Y), o.getAreaDeParede())));

        } // metodo que irá definir os layouts da arena

        public void setVidaVermelho(int n)
        {
            for (int i = 0; i < treds.Count; i++)
            {
                treds[i].setMass(n);
            }

        }
        public void setVidaAzul(int n)
        {
            for (int i = 0; i < tblues.Count; i++)
            {
                tblues[i].setMass(n);
            }

        }
        public void setAlcanceVermelho(int n)
        {

            for (int i = 0; i < treds.Count; i++)
            {
                treds[i].setAlcance(n);
            }
        }
        public void setAlcanceAzul(int n)
        {

            for (int i = 0; i < tblues.Count; i++)
            {
                tblues[i].setAlcance(n);
            }
        }
        public void setVelocidadeVermelho(float f)
        {
            for (int i = 0; i < treds.Count; i++)
            {
                treds[i].setMaxVelocity(f);
            }


        }
        public void setVelocidadeAzul(float f)
        {
            for (int i = 0; i < tblues.Count; i++)
            {
                tblues[i].setMaxVelocity(f);
            }


        }


        public void restart()
        {

            tblues.Clear();
            treds.Clear();

            for (int i = 1; i <= numeroDeTanques; i++)
            {
                Azuis b = new Azuis();
                Vector2 p = new Vector2((1000 + (10 * i)), (200 + (10 * i)));
                b.setPosition(p);
                b.ID = i;
                tblues.Add(b);


                Vermelhos tr = new Vermelhos();
                tr.setPosition(new Vector2((100 + (10 * i)), (200 + (10 * i))));
                tr.ID = i;
                treds.Add(tr);
            }


        }// para reniciar a simulação

        public void CriarParedes(int n)
        {
            switch (n)
            {
                case 1: obstaculos = paredes.getLista1(); break;
                case 2: obstaculos = paredes.getLista2(); break;
                case 3: obstaculos = paredes.getLista3(); break;
                case 4: obstaculos = paredes.getLista4(); break;
                case 5: obstaculos = paredes.getLista5(); break;
                default: obstaculos = paredes.getLista1(); break;
            }

            listParedes.Clear();

        } // Serve para criar todas as paredes

        public static Arena GetInstancia(Size d)
        {
            if (instancia == null) instancia = new Arena(d);
            return instancia;
        }

        public static Arena Instancia
        {
            get
            {
                if (instancia == null)
                    throw new InvalidOperationException("Objeto não criado. Criar com GetInstancia(.)");
                return instancia;
            }
        }
        public Size Area
        {
            get { return area; }
            set
            {
                if (value.Width > 20 && value.Height > 20)
                    area = value;
            }

        }

        private void ricochete(Boid tq)
        {
            Vector2
                pos = new Vector2(tq.getPosition().X, tq.getPosition().Y),
                velo = new Vector2(tq.getVelocity().X, tq.getVelocity().Y);

            if (tq.getPosition().X + tq.getRaio() > area.Width)
            {
                pos.X = area.Width - tq.getRaio();
                velo.X *= -30;
            }
            else if (tq.getPosition().X - tq.getRaio() < 0)
            {
                pos.X = tq.getRaio();
                velo.X *= -30;
            }

            if (tq.getPosition().Y + tq.getRaio() > area.Height)
            {
                pos.Y = area.Height - tq.getRaio();
                velo.Y *= -30;
            }
            else if (tq.getPosition().Y - tq.getRaio() < 0f)
            {
                pos.Y = tq.getRaio();
                velo.Y *= -30;
            }
            tq.setPosition(pos); tq.setVelocity(velo);
        }

        private void ricocheteParedes(Boid boid)
        {
            Vector2 velo = new Vector2(boid.getVelocity().X, boid.getVelocity().Y);

            //parede 1 

            foreach (Region o in listParedes)
            {
                if (o.IsVisible(boid.getHitbox()))
                {
                    velo.Y *= -4f;
                    velo.X *= -4f;
                    boid.setVelocity(velo);
                }
            }
        }// serve para delimitar as paredes

        public void move()
        {

            Vector2 v1, v2, v3, v4, vTotal;
            // mover todos os tanks azuis
            foreach (Azuis tb in tblues)
            {
                if (tb.Vivo == true)
                {
                    v1 = coesaoB(tb);
                    v2 = separacao(tb);
                    v3 = alinhamentoB(tb);
                    v4 = limiteB(tb);


                    vTotal = v1 / 40 + v2 + v3 + v4 + tb.getVelocity();
                    tb.setVelocity(vTotal);

                    ricochete(tb);
                    ricocheteParedes(tb);
                    tb.update();
                }
            }
            //mover todos os tanks vermelhos
            foreach (Vermelhos tr in treds)
            {
                if (tr.Vivo == true)
                {
                    v1 = coesaoR(tr);
                    v2 = separacao(tr);
                    v3 = alinhamentoR(tr);
                    v4 = limiteR(tr);



                    vTotal = v1 / 40 + v2 + v3 + v4 + tr.getVelocity();
                    tr.setVelocity(vTotal);


                    ricochete(tr);
                    ricocheteParedes(tr);
                    tr.update();
                }
            }


            // para cada lista de tiros disparar
            for (int i = 0; i < tirosB.Count; i++)
                tirosB[i].move();

            for (int i = 0; i < tirosR.Count; i++)
                tirosR[i].move();

        }

        public void checkVida()
        {
            for (int i = 0; i < treds.Count; i++)
                if (treds[i].Vivo == false) treds.Remove(treds[i]);
            for (int i = 0; i < tblues.Count; i++)
                if (tblues[i].Vivo == false) tblues.Remove(tblues[i]);

        }

        public void acao()
        {

            foreach (Azuis tb in tblues)
            {
                for (int i = 0; i < tirosR.Count; i++)
                {
                    if (tb.LevouTiroBlue(tirosR[i]) == true)
                        tirosR.Remove(tirosR[i]);
                }

                foreach (Vermelhos tr in treds)
                {
                    tb.Seekreds(tr);
                    if (timerBlue >= 31)
                        if (tb.Disparo == true && tr.Vivo == true)
                        {
                            Disparar bala = new Disparar(true);
                            bala.Pos = tb.getPosition();
                            bala.DisparoContraVermelho(tr);

                            tirosB.Add(bala);
                            timerBlue = 0;
                        }


                }

                timerBlue++;
            }



            foreach (Vermelhos tr in treds)
            {
                for (int i = 0; i < tirosB.Count; i++)
                {
                    if (tr.LevouTiroRed(tirosB[i]) == true)
                        tirosB.Remove(tirosB[i]);

                }


                foreach (Azuis tb in tblues)
                {
                    tr.Seekblues(tb);
                    if (timerRed >= 31)
                        if (tr.Disparo == true && tb.Vivo == true)
                        {
                            Disparar bala = new Disparar(false);
                            bala.Pos = tr.getPosition();
                            bala.DisparoContraAzul(tb);

                            tirosR.Add(bala);
                            timerRed = 0;
                        }

                }

                timerRed++;
            }

        }// o metodo que faz o disparar e o receber tiros

        // todos estes metodos são os usados para os tanques ficarem juntos como um grupo
        private Vector2 limiteB(Boid tq)
        {
            const float dv = 3;
            Vector2 v = new Vector2(0);

            if (tq.getPosition().X < 0) v.X = dv;
            else if (tq.getPosition().X > area.Width) v.X = -dv;
            if (tq.getPosition().Y < 0) v.Y = dv;
            else if (tq.getPosition().Y > area.Height) v.Y = -dv;

            return v;
        }

        private Vector2 alinhamentoB(Boid tq)
        {
            Vector2 pv = new Vector2(0);
            foreach (Azuis b in tblues)
            {
                if (tq != b)
                {
                    pv += b.getVelocity();
                }
            }
            pv /= (tblues.Count + 5);
            return (pv - tq.getVelocity()) / 8;
        }

        private Vector2 coesaoB(Boid tq)
        {
            Vector2 pc = new Vector2(0);
            foreach (Azuis b in tblues)
            {
                if (tq != b)
                {
                    pc += b.getPosition();
                }
            }
            pc /= (tblues.Count + 5);
            return (pc - tq.getPosition()) / 100;
        }

        private Vector2 limiteR(Boid tq)
        {
            const float dv = 3;
            Vector2 v = new Vector2(0);

            if (tq.getPosition().X < 0) v.X = dv;
            else if (tq.getPosition().X > area.Width) v.X = -dv;
            if (tq.getPosition().Y < 0) v.Y = dv;
            else if (tq.getPosition().Y > area.Height) v.Y = -dv;

            return v;
        }

        private Vector2 alinhamentoR(Boid tq)
        {
            Vector2 pv = new Vector2(0);
            foreach (Vermelhos r in treds)
            {
                if (tq != r)
                {
                    pv += r.getVelocity();
                }
            }
            pv /= (treds.Count + 5);
            return (pv - tq.getVelocity()) / 8;
        }

        private Vector2 coesaoR(Boid tq)
        {
            Vector2 pc = new Vector2(0);
            foreach (Vermelhos r in treds)
            {
                if (tq != r)
                {
                    pc += r.getPosition();
                }
            }
            pc /= (treds.Count + 5);
            return (pc - tq.getPosition()) / 100;
        }

        private Vector2 separacao(Boid boid)
        {
            Vector2 c = new Vector2(0);
            foreach (Vermelhos r in treds)
            {
                if (boid != r)
                {
                    if ((boid.getPosition() - r.getPosition()).Length() < 35)
                        c -= (r.getPosition() - boid.getPosition());
                }
            }
            foreach (Azuis b in tblues)
            {
                if (boid != b)
                {
                    if ((boid.getPosition() - b.getPosition()).Length() < 35)
                        c -= (b.getPosition() - boid.getPosition());
                }
            }
            return c / 4;
        }
        public void draw(Graphics g)
        {


            paredes.drawParedes(g);


            for (int i = 0; i < tblues.Count; i++)
                if (tblues[i].Vivo == true) tblues[i].draw(g);

            foreach (Disparar t in tirosB)
                t.draw(g);

            for (int i = 0; i < treds.Count; i++)
                if (treds[i].Vivo == true) treds[i].draw(g);

            foreach (Disparar t in tirosR)
            {
                t.draw(g);

            }

        }


        public Boolean Start
        {
            get { return start; }
            set { start = value; }
        }
    }

}
