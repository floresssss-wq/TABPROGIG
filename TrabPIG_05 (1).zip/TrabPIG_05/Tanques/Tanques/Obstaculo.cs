﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Tanques
{
    class Obstaculo
    {

        protected Point position;
        protected Size area;
        protected Point[] pontos;
        protected SolidBrush pincel;
        protected int rotation;
        protected List<Obstaculo> listaObstaculos;

        public Obstaculo()
        {

            position = new Point(0, 100);
            rotation = 0;
            area = new Size(200, 20);

            pincel = new SolidBrush(Color.DarkGray);
            listaObstaculos = new List<Obstaculo>();
 
            definePontos();


        }

        private void definePontos()
        {
            pontos = new Point[] {
                new Point(area.Width , -area.Height ),
                new Point(area.Width, area.Height),
                new Point(-area.Width, area.Height),
                new Point(-area.Width , -area.Height )
            };
        }
        // Os metodos getListanº sao os metodos usados para selecionar os layouts de obstaculos
        public List<Obstaculo> getLista1()
        {

            Obstaculo parede2 = new Obstaculo();
            Point p2 = new Point(250, 130);
            Size area2 = new Size(20, 200);
            parede2.setAreaDeParede(area2);
            parede2.setPosition(p2);

            Obstaculo parede3 = new Obstaculo();
            Point p3 = new Point(550, 250);
            Size area3 = new Size(20, 170);
            parede3.setAreaDeParede(area3);
            parede3.setPosition(p3);

            Obstaculo parede4 = new Obstaculo();
            Point p4 = new Point(850, 150);
            Size area4 = new Size(150, 20);
            parede4.setAreaDeParede(area4);
            parede4.setPosition(p4);

            Obstaculo parede5 = new Obstaculo();
            Point p5 = new Point(850, 350);
            Size area5 = new Size(400, 20);
            parede5.setAreaDeParede(area5);
            parede5.setPosition(p5);

            listaObstaculos.Add(this);
            listaObstaculos.Add(parede2);
            listaObstaculos.Add(parede3);
            listaObstaculos.Add(parede4);
            listaObstaculos.Add(parede5);
            return listaObstaculos;


        }
        public List<Obstaculo> getLista2()
        {

            position = new Point(100, 0);
            rotation = 0;
            area = new Size(20, 150);



            Obstaculo parede2 = new Obstaculo();
            Point p2 = new Point(50, 350);
            Size area2 = new Size(150, 20);
            parede2.setAreaDeParede(area2);
            parede2.setPosition(p2);

            Obstaculo parede3 = new Obstaculo();
            Point p3 = new Point(550, 150);
            Size area3 = new Size(20, 150);
            parede3.setAreaDeParede(area3);
            parede3.setPosition(p3);

            Obstaculo parede4 = new Obstaculo();
            Point p4 = new Point(700, 70);
            Size area4 = new Size(150, 20);
            parede4.setAreaDeParede(area4);
            parede4.setPosition(p4);

            Obstaculo parede5 = new Obstaculo();
            Point p5 = new Point(900, 250);
            Size area5 = new Size(20, 150);
            parede5.setAreaDeParede(area5);
            parede5.setPosition(p5);

            listaObstaculos.Add(this);
            listaObstaculos.Add(parede2);
            listaObstaculos.Add(parede3);
            listaObstaculos.Add(parede4);
            listaObstaculos.Add(parede5);
            return listaObstaculos;


        }
        public List<Obstaculo> getLista3()
        {
            position = new Point(150, 0);
            rotation = 0;
            area = new Size(20, 250);


            Obstaculo parede2 = new Obstaculo();
            Point p2 = new Point(350, 200);
            Size area2 = new Size(20, 250);
            parede2.setAreaDeParede(area2);
            parede2.setPosition(p2);

            Obstaculo parede3 = new Obstaculo();
            Point p3 = new Point(550, 0);
            Size area3 = new Size(20, 250);
            parede3.setAreaDeParede(area3);
            parede3.setPosition(p3);

            Obstaculo parede4 = new Obstaculo();
            Point p4 = new Point(750, 200);
            Size area4 = new Size(20, 250);
            parede4.setAreaDeParede(area4);
            parede4.setPosition(p4);

            Obstaculo parede5 = new Obstaculo();
            Point p5 = new Point(950, 0);
            Size area5 = new Size(20, 250);
            parede5.setAreaDeParede(area5);
            parede5.setPosition(p5);

            listaObstaculos.Add(this);
            listaObstaculos.Add(parede2);
            listaObstaculos.Add(parede3);
            listaObstaculos.Add(parede4);
            listaObstaculos.Add(parede5);
            return listaObstaculos;


        }       
        public List<Obstaculo> getLista4()
        {
            position = new Point(150, 70);
            rotation = 0;
            area = new Size(20, 300);


            Obstaculo parede2 = new Obstaculo();
            Point p2 = new Point(350, 300);
            Size area2 = new Size(20, 150);
            parede2.setAreaDeParede(area2);
            parede2.setPosition(p2);

            Obstaculo parede3 = new Obstaculo();
            Point p3 = new Point(350, 0);
            Size area3 = new Size(20, 150);
            parede3.setAreaDeParede(area3);
            parede3.setPosition(p3);

            Obstaculo parede4 = new Obstaculo();
            Point p4 = new Point(550, 100);
            Size area4 = new Size(30, 250);
            parede4.setAreaDeParede(area4);
            parede4.setPosition(p4);

            Obstaculo parede5 = new Obstaculo();
            Point p5 = new Point(750, 0);
            Size area5 = new Size(20, 150);
            parede5.setAreaDeParede(area5);
            parede5.setPosition(p5);

            Obstaculo parede6 = new Obstaculo();
            Point p6 = new Point(750, 300);
            Size area6 = new Size(20, 150);
            parede6.setAreaDeParede(area6);
            parede6.setPosition(p6);

            Obstaculo parede7 = new Obstaculo();
            Point p7 = new Point(950, 70);
            Size area7 = new Size(20, 300);
            parede7.setAreaDeParede(area7);
            parede7.setPosition(p7);


            listaObstaculos.Add(this);
            listaObstaculos.Add(parede2);
            listaObstaculos.Add(parede3);
            listaObstaculos.Add(parede4);
            listaObstaculos.Add(parede5);
            listaObstaculos.Add(parede6);
            listaObstaculos.Add(parede7);

            return listaObstaculos;


        }
        public List<Obstaculo> getLista5()
        {
            position = new Point(150, 90);
            rotation = 0;
            area = new Size(20, 100);


            Obstaculo parede2 = new Obstaculo();
            Point p2 = new Point(200, 250);
            Size area2 = new Size(20, 100);
            parede2.setAreaDeParede(area2);
            parede2.setPosition(p2);

            Obstaculo parede3 = new Obstaculo();
            Point p3 = new Point(300, 350);
            Size area3 = new Size(100, 20);
            parede3.setAreaDeParede(area3);
            parede3.setPosition(p3);

            Obstaculo parede4 = new Obstaculo();
            Point p4 = new Point(450, 100);
            Size area4 = new Size(20, 100);
            parede4.setAreaDeParede(area4);
            parede4.setPosition(p4);

            Obstaculo parede5 = new Obstaculo();
            Point p5 = new Point(500, 30);
            Size area5 = new Size(100, 20);
            parede5.setAreaDeParede(area5);
            parede5.setPosition(p5);

            Obstaculo parede6 = new Obstaculo();
            Point p6 = new Point(550, 250);
            Size area6 = new Size(100, 20);
            parede6.setAreaDeParede(area6);
            parede6.setPosition(p6);

            Obstaculo parede7 = new Obstaculo();
            Point p7 = new Point(700, 300);
            Size area7 = new Size(20, 100);
            parede7.setAreaDeParede(area7);
            parede7.setPosition(p7);

            Obstaculo parede8 = new Obstaculo();
            Point p8 = new Point(850, 150);
            Size area8 = new Size(20, 100);
            parede8.setAreaDeParede(area8);
            parede8.setPosition(p8);


            Obstaculo parede9 = new Obstaculo();
            Point p9 = new Point(950, 300);
            Size area9 = new Size(100, 20);
            parede9.setAreaDeParede(area9);
            parede9.setPosition(p9);

            Obstaculo parede10 = new Obstaculo();
            Point p10 = new Point(650, 100);
            Size area10 = new Size(100, 20);
            parede10.setAreaDeParede(area10);
            parede10.setPosition(p10);

            Obstaculo parede11 = new Obstaculo();
            Point p11 = new Point(10, 350);
            Size area11 = new Size(100, 20);
            parede11.setAreaDeParede(area11);
            parede11.setPosition(p11);

            Obstaculo parede12 = new Obstaculo();
            Point p12 = new Point(950, 100);
            Size area12 = new Size(100, 20);
            parede12.setAreaDeParede(area12);
            parede12.setPosition(p12);

            Obstaculo parede13 = new Obstaculo();
            Point p13 = new Point(250, 100);
            Size area13 = new Size(100, 20);
            parede13.setAreaDeParede(area13);
            parede13.setPosition(p13);


            listaObstaculos.Add(this);
            listaObstaculos.Add(parede2);
            listaObstaculos.Add(parede3);
            listaObstaculos.Add(parede4);
            listaObstaculos.Add(parede5);
            listaObstaculos.Add(parede6);
            listaObstaculos.Add(parede7);
            listaObstaculos.Add(parede8);
            listaObstaculos.Add(parede9);
            listaObstaculos.Add(parede10);
            listaObstaculos.Add(parede11);
            listaObstaculos.Add(parede12);
            listaObstaculos.Add(parede13);
            return listaObstaculos;


        }

        

        public Point getPosition()
        {
            return position;
        }

        public void setPosition(Point p)
        {
            position = p;
        }

        public Size getAreaDeParede()
        {
            return area;
        }
        public void setAreaDeParede(Size s)
        {

            area = s;
        }

        public int getRotation()
        {
            return rotation;
        }

        public void setRotation(int r)
        {
            rotation = r;
        }

        public virtual void draw(Graphics g)
        {

            g.ResetTransform();
            g.TranslateTransform(position.X, position.Y, MatrixOrder.Append);
            g.RotateTransform(rotation);
            g.FillPolygon(pincel, pontos);

        }


        public virtual void drawParedes(Graphics g)
        {
            List<Region> listParedes = new List<Region>();
            foreach (Obstaculo o in listaObstaculos)
                listParedes.Add(new Region(new Rectangle(new Point((int)o.getPosition().X, (int)o.getPosition().Y), o.getAreaDeParede())));
            for (int i = 0; i < listParedes.Count; i++)
                g.FillRegion(new SolidBrush(Color.DarkGray), listParedes[i]);




        }
    }
}
