﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Tanques
{
    class Disparar
    {
        private Vector2 position, velocity;
        float rotation;
        private int timer;
        private SolidBrush pincel;
        private SizeF dim;
        private Boolean tiroBlue;


        public Disparar(Boolean b)
        {
            tiroBlue = b;
            timer = 0;
            position = new Vector2(0, 0);
            velocity = new Vector2(2);
            pincel = new SolidBrush(Color.Black);
            dim = new SizeF(10, 10);
            rotation = 0;
        }
        public Vector2 Pos
        {
            get { return position; }
            set { position = value; }
        }
        public int Timer
        {

            get { return timer; }
            set { timer = value; }
        }
        public Vector2 Velo
        {
            get { return velocity; }
            set { velocity = value; }
        }

        public Boolean TiroBlue
        {

            get { return tiroBlue; }
            set { tiroBlue = value; }
        } // para diferenciar entre balas azuis e vermelhas temos este boolean que nos diz;




        public void DisparoContraVermelho(Vermelhos tr)
        {

            Vector2 d = new Vector2((tr.getPosition().X - Pos.X), (tr.getPosition().Y - Pos.Y));
            if (tiroBlue == true )
            {
               
                Velo = new Vector2(d.X / 10, d.Y / 10);
                
            }
            
        }// metodo que recebe um tank vermelho e usa o como alvo

        public void DisparoContraAzul(Azuis tb)
        {
            Vector2 d = new Vector2((tb.getPosition().X - Pos.X), (tb.getPosition().Y - Pos.Y));
            if (tiroBlue == false)
            {
               
                Velo = new Vector2(d.X / 10, d.Y / 10);
                
            }

        }// metodo que recebe um tank azul e usa o como alvo

        public void move()
        {
            Pos += Velo;

        }
        public void draw(Graphics g)
        {

            {
                RectangleF rect = new RectangleF(new Point((int)-dim.Width / 2, (int)dim.Height / 2), dim);
                g.ResetTransform();
                g.RotateTransform(rotation);
                g.TranslateTransform(Pos.X, Pos.Y, MatrixOrder.Append);
                g.FillEllipse(pincel, rect);
            }
        }


    }
}
